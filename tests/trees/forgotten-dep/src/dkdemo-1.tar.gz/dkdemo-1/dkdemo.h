int dkdemo(void);
