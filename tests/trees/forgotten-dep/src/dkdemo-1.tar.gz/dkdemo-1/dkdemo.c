#include "dkdemo.h"
int dkdemo(void) { return 42; }
